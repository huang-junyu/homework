# Cpsc351Assignment1
Assignment 1 for CPSC 351

Section #2

Programming Language: C++

Extra Credit Implemented: No

Team Members & Contributions:

Tyler Groom tjgroom@csu.fullerton.edu
Created the makefile, helped navigate receiver file, debugged majority of errors in receiver and some in sender.

Anthony Berton acberton1@csu.fullerton.edu
Implemented the reciever file and helped fixed bugs related to the file. 

Titus Sudarno sudarno08@csu.fullerton.edu
Implemented the sender file.


Thomas-James Le tjle@csu.fullerton.edu
Helped navigate the sender file and fix errors in the file.

How the Program works:
For the sender file create a file containing the string "Hello world." Then use the ftok
command to generate the key. Then retrieve the ID of the shared memory segment and
attach it to shared memory and the message queue. In the cleanUp function detach the key
from the shared memory. In the send function, the key file is opened for reading. Send a
message of type SENDER_DATA_TYPE to the reciever. Then wait on the reveiver to sends a
message of type RECV_DONE TYPE which tells us that it has finished saving the memory.
Tell the reciever that there is nothing else to send and then close the file.

For the reciever file create a file and generate the key using ftok. Allocate a piece of 
shared memory of the size SHARED_MEMORY_CHUNK_SIZE. Attach the key to shared memory and
create a message queue. In the mainloop function, recieve the message from the sender
and get the message size. Then tell the sender that the reciever is ready for the next
file. In the cleanUp function, detatch the key from the shared memory, deallocate the
shared memory chunk and the message queue. In the main function, install a signal
handler using signaldemo.cpp. 


Running the program: 

In the terminal, navigate to the directory where the project is kept.

enter make
enter ./receiver

(in a new window, in same directory)
enter ./sender file.txt

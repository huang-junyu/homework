CPSC 351 section-03 
Assignment 1
-------------------------------------------------------------------------------------------------------------------
Sicheng Long	xlongx@csu.fullerton.edu
Kun Fang		fangkun1996@csu.fullerton.edu
-------------------------------------------------------------------------------------------------------------------
The programming language we used is C++
-------------------------------------------------------------------------------------------------------------------
The following steps are how to execute our program：
Before running the program ensure you are in the Linux System or other System similar with Linux
1. Make sure all the files are in one folder
2. Open the terminal and make sure you are in the correct directory
3. Type "make" then enter
4. Type "./sender keyfile.txt"
5. Open another terminal from the same directory
6. Type "./recv"
7. The terminals will show the outputs for both processes
8. The file "recvfile" contains the message received by the receiver
-------------------------------------------------------------------------------------------------------------------
Extra creidt: no
-------------------------------------------------------------------------------------------------------------------
The picture named "Output1.png"in the directory is how the program work, if the steps above you do not understand then
you can look the pic and try again to run the program.
If you are interested in our project, there is another file named "1.txt" for you to test.
Follow the steps shown before, in step 4, type "./sender 1.txt", the terminals will show the results like the picture named "Output2.png", "recvfile" will contains the article from 1.txt. 
-------------------------------------------------------------------------------------------------------------------
Contribution:
Both of us worked on the implementation of the program and the design of the assignment. Before we started this program,
we dicussed a lot about this project and how this program work from. We collaborated with each other online because the 
situation happened in the US. Both of us made a great effort in the coding part, we discussed a lot for every function we wrote. After finishing the code part, Sicheng Long did the receiver flow diagram and Kun Fang did the sender flow diagram. Both of us put large efforts on this project to get higher grade as we can.
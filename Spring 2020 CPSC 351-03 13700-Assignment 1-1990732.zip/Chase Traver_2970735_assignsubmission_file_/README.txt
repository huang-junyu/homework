NAMES AND EMAILS:
Section 03, Chase Traver, chasetraver@csu.fullerton.edu
Section 03, Benjamin Baesu, bbaesu@csu.fullerton.edu

Program was coded in c++ on Linux (Ubuntu).

HOW TO RUN PROGRAM
compile code using g++ or other c/c++ compiler.
run sender executable and recv executable using termial using functions ./sender <file.txt> and ./recv
For best results, ./recv should run first, or programs should be run simultaneously using a makefile.
Program is made on Ubuntu (Linux). 
Program will run automatically sending from one file and receiving in another, as long as the text file is included in the directory.
Screenshots are included in this directory.

TEAM COLLABORATION:
recv.cpp was coded by Benjamin Baesu.
sender.cpp was coded by Chase Traver.
Along with these contributions, Chase Traver worked on the design module and README, while Benjamin Baesu worked on final touches, screenshots, and testing.
